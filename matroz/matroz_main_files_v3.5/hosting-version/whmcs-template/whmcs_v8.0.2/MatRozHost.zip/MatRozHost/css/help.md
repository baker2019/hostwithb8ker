Reference ID: Cupcake - Apple
